<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ServiceCategory;
use Faker\Generator as Faker;

$factory->define(ServiceCategory::class, function (Faker $faker) {
    return [
        //
    ];
});
