<?php

namespace App\Enums;

abstract class SpacingType
{
    const DoubleLine           = 'double';
    const SingleLine           = 'single';
    

}
