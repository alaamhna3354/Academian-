<?php

return [
	'dropdown_select_text' => 'Select',
    'sign_in' => 'Sign In',
    'please_enter_email_password' => 'Please enter your email and password',
    'orders' => 'Orders',
    'order' => 'Order',
    'order_now'	=> 'Order Now',
    'customers' => 'Customers',
    'team_members' => 'Team Members',
    'my_account' => 'My Account',
    'type_of_work' => 'Type of work',
    'subject' => 'Subject',
    'title' => 'Title',
    'level' => 'Level',
    'instruction' => 'Instruction'

];