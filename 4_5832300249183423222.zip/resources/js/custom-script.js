$(function() {
    $("body").tooltip({
        selector: '[data-toggle="tooltip"]'
    });
    bsCustomFileInput.init();
});
