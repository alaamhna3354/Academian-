<notification
:url_push_notification="'{{ route('get_push_notification_count') }}'"
:url_get_notifications="'{{ route('get_unread_notifications') }}'"
:url_notification_list_page="'{{ route('notifications_index') }}'"
:url_mark_all_as_read="'{{ route('notification_all_mark_as_read') }}'"
></notification>


